<?php get_header(); ?>

 <div class="row">
  <div class="span8 main">
   <?php endwhile; else: ?>
    <p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
  </div>
 </div>

<?php page(); ?>
<?php get_footer(); ?>