<?php get_header(); ?>
<DIV class="row">
<?php
$a     = array("sisangan"=>"a","sahel"=>"b","jangal"=>"c");
$class_name = array_rand($a,1);
echo "
      <header class='span12 slide-" . $class_name . "'>


        <div class='text-box " . $class_name . "'>";

  if ($class_name == "sisangan")
  {
    dynamic_sidebar( 'widget-sisangan' );
  }
  elseif ($class_name == "sahel")
  {
    dynamic_sidebar( 'widget-sahel' );
  }
  elseif ($class_name == "jangal")
  {
    dynamic_sidebar( 'widget-jangal' );
  }
?></div>

 </div>
 </header>

 <div class="span12 property">
   <p><?php bloginfo('description'); ?></p>
 </div>

 <div class="span12 detail">
  <div class="row">
    <div class="span6 populate">
      <p>جمعیت</p>
      <p><i class="fa fa-user" aria-hidden="true"></i> ۱۲۸,۶۴۷ نفر</p>
    </div>
    <div class="span6 height">
      <p>ارتفاع از سطح دریا</p>
      <p><i class="fa fa-arrows-v" aria-hidden="true"></i> ۲۰/۹- متر</p>
    </div>
  </div>
 </div>

  <div class="span12 port">
    <div class="row">
      <div class="span7"></div>
      <div class="span5 text-box">
    <?php dynamic_sidebar( 'widget-port' ); ?>
    </div>
  </div>
  </div>



 <div class="hotel">
    <div class="container">
      <div class="property">
        <p>برای اقامت در نوشهر، مشکلی نخواهید داشت.</p>
      </div>
    </div>
  </div>

<div class="images-box">
  <div class="container">
    <div class="row">
      <div class="span4 hotel_img">
        <div class="cover"><h3><strong>هتل</strong></h3><img src="http:\\static.dev\images\hotel.png"></div>
      </div>

      <div class="span4 vila">
        <div class="cover"><h3><strong>ویلا</strong></h3><img src="http:\\static.dev\images\vila.png"></div>
      </div>

      <div class="span4 suit">
        <div class="cover"><h3><strong>سوئیت</strong></h3><img src="http:\\static.dev\images\Home.svg.png"></div>
      </div>
    </div>
  </div>
</div>



 <div class="span12 airport">
  <div class="row">
    <div class="span4 text-box">
    <?php dynamic_sidebar( 'widget-airport' ); ?>
    </div>
    <div class="span8"></div>
  </div>
 </div>





 <div class="span12 map" >
    <div class="overlay">
      <p>برای دیدن نقشه کلیلک کنید <span class="fa-stack fa-lg">
        <i class="fa fa-circle-thin fa-stack-2x"></i>
        <i class="fa fa-hand-o-up fa-stack-1x"></i></span>
      </p>
    </div>
      <?php dynamic_sidebar( 'widget-map' ); ?>
    </div>


 <footer>
<div class="copyright"><h6>طراحی شده توسط <a href="https://github.com/ali-modabber">علی مدبر</a> در <a href="http://ermile.com/fa">ارمایل</a> &copy; 2016 </h6><?php
    $currentYear = date('Y');
    if (2016 < $currentYear)
    {
      echo '-' . $currentYear;
    }
    ?>
   </div>
 </footer>
</DIV>
</body>
</html>

