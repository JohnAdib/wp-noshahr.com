<?php

add_theme_support( 'menus' );


// Add Your Menu Locations
function register_my_menus()
{
  register_nav_menus(
  [
    'menu_header'  => 'منوی بالای صفحه',
    'menu_nav'     => 'ناوبری',
    'menu_sidebar' => 'منوی نوار کناری',
    'menu_footer'  => 'منوی فوتر',
                        'link_before' => '<span>sss',
                        'link_after' => '</span>',
                        'header_menu' => 'Header Menu',
  ]
  );
}


function theme_widgets_init()
{
  $site_title = '؛ <h1>'. get_bloginfo('name'). ' </h1> ';

  register_sidebar( [
    'name'          => 'widget-port',
    'before_widget' => '<p>',
    'after_widget'  => '</p>',
  ]);

  register_sidebar( [
    'name'          => 'widget-airport',
    'before_title'  => '<h2>',
    'after_title'   => '</h2>',
    'before_widget' => '<p>',
    'after_widget'  => '</p>',
  ]);

  register_sidebar( [
    'name'          => 'widget-sisangan',
    'before_title'  => '<h2>',
    'after_title'   => "</h2>$site_title",
  ]);

    register_sidebar( [
    'name'          => 'widget-sahel',
    'before_title'  => '<h2>',
    'after_title'   => "</h2>$site_title",
  ]);

    register_sidebar( [
    'name'          => 'widget-jangal',
    'before_title'  => '<h2>',
    'after_title'   => "</h2>$site_title",
  ]);

    register_sidebar( [
    'name'          => 'widget-map',
  ]);

    register_sidebar( [
    'name'          => 'widget-eghamat',
  ]);
}

add_action( 'widgets_init', 'theme_widgets_init' );



add_action( 'init', 'register_my_menus' );
?>