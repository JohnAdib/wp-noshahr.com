 <footer>
<div class="copyright"><h6> <a href="https://github.com/ali-modabber">طراحی شده</a> در <a href="http://ermile.com/fa">ارمایل</a> &copy; 2016 </h6><?php
    $currentYear = date('Y');
    if (2016 < $currentYear)
    {
      echo '-' . $currentYear;
    }
    ?>
   </div>
 </footer>
<!-- </DIV> -->
</body>
</html>